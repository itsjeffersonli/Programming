package com.healthcareroom;

public abstract class HospitalRoomInfo {
	public abstract void patientInformation();
	public abstract void doctorInformation();
	public abstract void roomAssigned();
}
